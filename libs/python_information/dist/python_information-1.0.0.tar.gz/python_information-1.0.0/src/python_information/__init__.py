"""_summary_
"""
from .core import print_details_about_python
from .exceptions import ParametersError

__all__ = ["print_details_about_python", "ParametersError"]
__version__ = "1.0.0"
